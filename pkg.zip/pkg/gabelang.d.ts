/* tslint:disable */
/* eslint-disable */
/**
 * Wasm Interpretter Binding for the gabelang language
 */
export class Gabelang {
  free(): void;
  /**
   * Creates a new interpretter
   */
  constructor();
  /**
   * Returns the repl greeting text
   */
  static repl_greeting(): string;
  /**
   * Executes a gabelang program
   */
  run_program(program: string): string;
  /**
   * Executes a line of gabelang code
   */
  execute(code: string): string;
  /**
   * Resets the GabrEnvironment including all variable scopes
   */
  reset_scope(): void;
  /**
   * Pushes a new stack frame on to the stack
   */
  push_frame(): void;
  /**
   * Pops a stack frame off of the stack
   */
  pop_frame(): boolean;
}
