import * as wasm from "./gabelang_bg.wasm";
export * from "./gabelang_bg.js";
import { __wbg_set_wasm } from "./gabelang_bg.js";
__wbg_set_wasm(wasm);