/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_gabelang_free: (a: number, b: number) => void;
export const gabelang_new: () => number;
export const gabelang_repl_greeting: (a: number) => void;
export const gabelang_execute: (a: number, b: number, c: number, d: number) => void;
export const gabelang_reset_scope: (a: number) => void;
export const gabelang_push_frame: (a: number) => void;
export const gabelang_pop_frame: (a: number) => number;
export const gabelang_run_program: (a: number, b: number, c: number, d: number) => void;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
